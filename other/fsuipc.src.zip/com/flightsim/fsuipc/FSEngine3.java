package com.flightsim.fsuipc;

public class FSEngine3
  extends FSEngine
{
  public FSEngine3()
  {
    this.iMixAddress = 2496;
    this.iStartAddress = 2498;
    this.iCombustionAddress = 2500;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSEngine3
 * JD-Core Version:    0.7.0.1
 */