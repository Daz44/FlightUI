package com.flightsim.fsuipc;

public class FSFlightSim
  extends FSUIPC
{
  public String StartSituationName()
  {
    return getString(36, 255);
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSFlightSim
 * JD-Core Version:    0.7.0.1
 */