package com.flightsim.fsuipc;

public class FSNav2
  extends FSNavRadio
{
  public FSNav2()
  {
    this.iStandbyFreq = 12576;
    this.iFreq = 850;
    this.iID = 12319;
    this.iName = 12325;
    this.iSwap = 12579;
    this.iLocNeedle = 3161;
    this.iGlideSlope = 3145;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSNav2
 * JD-Core Version:    0.7.0.1
 */