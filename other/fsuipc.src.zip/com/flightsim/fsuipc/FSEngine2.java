package com.flightsim.fsuipc;

public class FSEngine2
  extends FSEngine
{
  public FSEngine2()
  {
    this.iMixAddress = 2344;
    this.iStartAddress = 2346;
    this.iCombustionAddress = 2348;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSEngine2
 * JD-Core Version:    0.7.0.1
 */