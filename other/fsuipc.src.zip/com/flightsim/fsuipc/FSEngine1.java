package com.flightsim.fsuipc;

public class FSEngine1
  extends FSEngine
{
  public FSEngine1()
  {
    this.iMixAddress = 2192;
    this.iStartAddress = 2194;
    this.iCombustionAddress = 2196;
    this.iValueOffset = 2188;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSEngine1
 * JD-Core Version:    0.7.0.1
 */