package com.flightsim.fsuipc;

public class FSEngine4
  extends FSEngine
{
  public FSEngine4()
  {
    this.iMixAddress = 2648;
    this.iStartAddress = 2650;
    this.iCombustionAddress = 2652;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSEngine4
 * JD-Core Version:    0.7.0.1
 */