package com.flightsim.fsuipc;

public class FSNav1
  extends FSNavRadio
{
  public FSNav1()
  {
    this.iStandbyFreq = 12574;
    this.iFreq = 848;
    this.iID = 12288;
    this.iName = 12294;
    this.iSwap = 12579;
    this.iLocNeedle = 3144;
    this.iGlideSlope = 3145;
  }
}


/* Location:           C:\Users\Daz\Documents\FSUIPC\UIPC_SDK_JAVA\UIPC_SDK_JAVA\fsuipc.jar
 * Qualified Name:     com.flightsim.fsuipc.FSNav1
 * JD-Core Version:    0.7.0.1
 */